﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WpfApp2.model;

namespace WpfApp2.persistencia
{
    internal class BD
    {
        public static int IndexBDGlobal { get; set; } = 0;

        public static List<ideiaInovadora> mybd = new();

        //public static void SalvarBD(ideiaInovadora i) => mybd.Add(i);

        public static List<ideiaInovadora> RetomarBD() => mybd;
        public static void SalvarBD(ideiaInovadora i)
        {
            if(i.IdideiaInovadora == 0)
            {
                i.IdideiaInovadora = ++IndexBDGlobal;
                mybd.Add(i);
            }
        }

        public static ideiaInovadora? RetomarBD(int id)
        {
            ideiaInovadora? objRec = null;
            if (VerificarSeExiste(id)) {
                objRec = mybd.Find(objIdeia_r => { return objIdeia_r.IdideiaInovadora == id; });
            }
            return objRec;
        }

        private static Boolean VerificarSeExiste(int id)
        {
            return mybd.Exists(objIdeia_e => { return objIdeia_e.IdideiaInovadora == id; });
        }
    }
}

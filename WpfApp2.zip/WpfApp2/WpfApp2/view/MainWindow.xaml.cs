﻿using System.Diagnostics;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp2.control;
using WpfApp2.persistencia;
using WpfApp2.view;

namespace WpfApp2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {

        private ideiaInovadoraControle objClasseIdeiaInovadora = new();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void TextBoxIdeia_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void TextBoxCusto_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            if (!string.IsNullOrEmpty(TextBoxAtuacao.Text) && !string.IsNullOrEmpty(TextBoxIdeia.Text))
            {
                
                if(objClasseIdeiaInovadora.ControleCadastrarideiaInovadora(TextBoxAtuacao.Text, TextBoxIdeia.Text, float.Parse(TextBoxCusto.Text)))
                MessageBox.Show("Cadastro realizado com sucesso meu nobre");
            }
            else
            {
                MessageBox.Show("Campos obrigatórios devem ser preenchidos");
            }

            Debug.WriteLine("=================");
            BD.RetomarBD().ForEach(x =>  Debug.WriteLine(x));
            Debug.WriteLine("=================");

        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {

            Window1 w1 = new();
            w1.Show();

        }
    }
}